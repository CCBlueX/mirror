﻿>>> LiquidBounce

>> Install Instruction
1. Install Forge (http://files.minecraftforge.net/maven/net/minecraftforge/forge/index_1.8.9.html)
2. Create "mods" folder in the ".minecraft" folder
3. Put the "LiquidBounce1.8.9" into the "mods" folder.
4. Launch minecraft with forge 1.8.9.

Copyright © 2018 | CCBlueX | All rights reserved.